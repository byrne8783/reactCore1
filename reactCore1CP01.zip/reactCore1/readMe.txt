want to get Bootstrap/jquery/its two siblings/popper.js/toottip.js integrated into webPack so it generates the dist files
Meanwhile :
https://blogs.taiga.nl/martijn/2017/11/24/building-and-asp-net-core-mvc-app-with-npm-and-webpack-asp-net-core-2-0-edition/
https://codeburst.io/how-to-use-webpack-in-asp-net-core-projects-a-basic-react-template-sample-25a3681a5fc2
provide guidance

