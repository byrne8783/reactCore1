﻿require('./lib');
document.getElementById("fillthis").innerHTML = getText();
