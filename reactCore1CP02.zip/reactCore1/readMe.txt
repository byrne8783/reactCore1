Meanwhile :
https://blogs.taiga.nl/martijn/2017/11/24/building-and-asp-net-core-mvc-app-with-npm-and-webpack-asp-net-core-2-0-edition/
https://codeburst.io/how-to-use-webpack-in-asp-net-core-projects-a-basic-react-template-sample-25a3681a5fc2
provide guidance

Right now :
want to get Bootstrap/jquery/its two siblings/popper.js/toottip.js integrated into webPack so it generates the dist files
I have jQuery integrated with a manual build ('npm run wbp') and have a plugin to automatically load jQuery, 
so basically I'm at the 'ES6 (ES2015)' stage of 'a-basic-react-template-sample-25a3681a5fc2'.  Unfortunately this bit has destroyed the APP - nothing now works in any browser

SO, next step is to back-out the Babel loader.  In the endof the day I wanna go for Typescript anyway!




Onward and Upward
get your head around this webpack production/development bundle thingy

get your head around the 'extract text' and uglify thingy'sample-25a3681a5fc2

do the funky hot module replacement

switch to typescript 3.0 as your language of choice.  That means you have to integrate thanspilation into js and also HMR of the js to the browser

Add React to your projects-a-basic-react-template-sample-25a3681a5fc2
Figure out the various ways React plays with Razor and optimise the HTML accordingly

Write a React component, such as a 'tag helper' , maybe even a calendar component.  
Here's a primer https://blog.flowandform.agency/create-a-custom-calendar-in-react-3df1bfd0b728


