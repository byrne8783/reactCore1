﻿getText = function () {
    return "Data from getText function in lib.js";
};
