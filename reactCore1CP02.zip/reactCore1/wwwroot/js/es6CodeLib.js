﻿export default class ES6Lib {

    constructor() {
        this.text = "Data from ES6 class ES6Lib";
    }

    getData() {
        return this.text;
    }
}
